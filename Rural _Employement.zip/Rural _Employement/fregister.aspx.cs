﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class fregister : System.Web.UI.Page
{
    SqlConnection con=new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\HP\Documents\Visual Studio 2013\WebSites\StudygramFinal\App_Data\student.mdf;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            clear();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string nm = TextBox1.Text;
        string email = TextBox2.Text;
        double mno = Convert.ToInt64(TextBox3.Text);
        string pass = TextBox4.Text;
        string cpass = TextBox5.Text;

        SqlCommand cmd = new SqlCommand("insert into fregister values(@name,@mail,@mobile,@pas,@cpas)", con);
        cmd.Parameters.AddWithValue("@name", nm);
        cmd.Parameters.AddWithValue("@mail", email);
        cmd.Parameters.AddWithValue("@mobile", mno);
        cmd.Parameters.AddWithValue("@pas", pass);
        cmd.Parameters.AddWithValue("@cpas", cpass);

        con.Open();
        int row = cmd.ExecuteNonQuery();


        if (row > 0)
        {
            Response.Write("<script>alert('Registration Successfully Done.')</script>");
            Response.Redirect("flogin.aspx");
            clear();
        }
        else
        {
            Response.Redirect("<script>alert('Registration Successfully Not Done.')</script>");

        }
        con.Close();
    }
    
    public void clear()
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
        TextBox3.Text = "";
        TextBox4.Text = "";
        TextBox5.Text = "";

        TextBox1.Focus();
    }
}
