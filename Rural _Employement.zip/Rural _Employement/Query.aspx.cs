﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;


public partial class Query : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\HP\Documents\Visual Studio 2013\WebSites\StudygramFinal\App_Data\student.mdf;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            clear();
        }

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        
        string name = TextBox1.Text;
        string query = TextBox2.Text;

        SqlCommand cmd = new SqlCommand("insert into query values(@name,@query)", con);
        
        cmd.Parameters.AddWithValue("@name", name);
        cmd.Parameters.AddWithValue("@query", query);
        

        con.Open();
        int row = cmd.ExecuteNonQuery();


        if (row > 0)
        {
            Response.Write("<script>alert('Registration Successfully Done.')</script>");
            Response.Redirect("home.aspx");
            clear();
        }
        else
        {
            Response.Redirect("<script>alert('Registration Successfully Not Done.')</script>");

        }
        con.Close();
    }
    
    public void clear()
    {
        TextBox1.Text = "";
        TextBox2.Text = "";
        

        TextBox1.Focus();
    }

    }
