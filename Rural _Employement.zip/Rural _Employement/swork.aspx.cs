﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class swork : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\HP\Documents\Visual Studio 2013\WebSites\StudygramFinal\App_Data\student.mdf;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            dropbind();
            bindgrid();
        }
    }

    public void bindgrid()
    {
        SqlDataAdapter da = new SqlDataAdapter("select *from work", con);
        DataSet ds = new DataSet();
        da.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }


    protected void Button1_Click(object sender, EventArgs e)
    {
        string asub = DropDownList1.SelectedItem.Text;
        SqlDataAdapter adp1 = new SqlDataAdapter("select * from work where subject='" + asub +"'", con);
        DataSet ds = new DataSet();
        adp1.Fill(ds);
        GridView1.DataSource = ds;
        GridView1.DataBind();
    }

    public void dropbind()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("select type FROM type", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        DropDownList1.DataSource = ds;
        DropDownList1.DataTextField = "type";
        DropDownList1.DataBind();
        DropDownList1.Items.Insert(0, new ListItem("--SELECT--", "0"));
        con.Close();
    }
}