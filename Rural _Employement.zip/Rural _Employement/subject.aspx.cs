﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class subject : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\HP\Desktop\labmanagement\App_Data\student.mdf;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            clear();
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        string type = TextBox1.Text;
        SqlCommand cmd = new SqlCommand("insert into type values(@type)", con);
        cmd.Parameters.AddWithValue("@type", type);

        con.Open();
        int row = cmd.ExecuteNonQuery();

        if (row > 0)
        {
            Response.Write("<script>alert('Successfully Submitted')</script>");
            clear();
        }
        con.Close();
    }

    public void clear()
    {
        TextBox1.Text = "";

        TextBox1.Focus();
    }
}