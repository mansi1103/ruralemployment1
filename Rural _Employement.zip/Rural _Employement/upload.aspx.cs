﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.SqlClient;

public partial class upload : System.Web.UI.Page
{
    SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\HP\Desktop\labmanagement\App_Data\student.mdf;Integrated Security=True");
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!IsPostBack)
        {
            clear();
            dropbind();
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        string nm = TextBox1.Text;
        double enroll = Convert.ToInt64(TextBox3.Text);
        string sub = DropDownList1.SelectedItem.Text;
        string work = Server.MapPath("~/swork/") + FileUpload2.FileName;
        FileUpload2.PostedFile.SaveAs(work);

        SqlCommand cmd = new SqlCommand("insert into work values(@name,@enroll,@subj,@work)", con);
        cmd.Parameters.AddWithValue("@name", nm);
        cmd.Parameters.AddWithValue("@enroll", enroll);
        cmd.Parameters.AddWithValue("@subj", sub);
        cmd.Parameters.AddWithValue("@work", work);

        con.Open();
        int row = cmd.ExecuteNonQuery();
        if (row > 0)
        {
            Response.Write("<script>alert('Data Successfully Submitted')</script>");
            clear();
        }
        
    }

    public void dropbind()
    {
        con.Open();
        SqlCommand cmd = new SqlCommand("select type FROM type", con);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataSet ds = new DataSet();
        da.Fill(ds);
        DropDownList1.DataSource = ds;
        DropDownList1.DataTextField = "type";
        DropDownList1.DataBind();
        DropDownList1.Items.Insert(0, new ListItem("--SELECT--", "0"));
        con.Close();
    }
    public void clear()
    {
        TextBox1.Text = "";
        TextBox3.Text = "";
        DropDownList1.ClearSelection();

        TextBox1.Focus();
    }
}